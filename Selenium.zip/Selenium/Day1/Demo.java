package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Demo
{
	public static void main(String args[]) 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://facebook.com");
		System.out.println(driver.getTitle());
		
		driver.findElement(By.cssSelector("#email.inputtext")).sendKeys("anmol");
		driver.findElement(By.id("email")).sendKeys("anmol");
	   
		//driver.findElement(By.xpath("//*[@id=\"loginbutton\"]")).click();
		/*WebElement we=driver.findElement(By.id("email"));
		we.sendKeys("anmolsivastva5000@gmail.com");*/
		WebElement we=driver.findElement(By.id("day"));
		Select sel=new Select(we);
		sel.selectByVisibleText("9");
		WebElement wee=driver.findElement(By.id("month"));
		Select sell=new Select(wee);
		sell.selectByVisibleText("Jun");
		WebElement weee=driver.findElement(By.id("year"));
		Select selll=new Select(weee);
		selll.selectByVisibleText("1996");
		
		
	}
}
//we will handlelogin with css
//we will provide link to selenium too by seeing href
//driver.findElement(By.linkText("Forgotten account?")).click();
//class should not have wide spaces else it will give error message compoun dclasses not allowed
//sometimes id and names are common for two fields hence selenium confuse scan from top left and consider first name
//hence provide unique attribute
//we will have to use tools to get xpath and css
//driver.findElement(By.name("q")).sendKeys("stackoverflow");
//there is no guarantee that there will be id name class for every element Hence we prefer
//xpath and css