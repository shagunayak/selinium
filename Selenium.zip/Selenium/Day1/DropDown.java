package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDown 
{
	public static void main(String args[]) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver wb=new ChromeDriver();
		wb.get("http://www.spicejet.com");
		WebElement we=wb.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
		
		Select sel=new Select(we);
		sel.selectByVisibleText("USD");
		//we can also select by value inside tag too
		//for getting 3 adults
		WebElement w=wb.findElement(By.id("divpaxinfo"));
		System.out.println(w.getText());
		w.click();
		Thread.sleep(2000);
		WebElement wee=wb.findElement(By.id("hrefIncAdt"));
		
		for(int i=1;i<=3;i++) 
		{
			wee.click();
		}
		WebElement we1=wb.findElement(By.id("btnclosepaxoption"));
		we1.click();
		
        System.out.println(w.getText());
		//xpath forbanglore will be //a[@Value='BLR']
        //xpath for chennai will be //a[@Value='MAA']
        wb.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
        Thread.sleep(4000);
        wb.findElement(By.xpath("//a[@value='BLR']")).click();
        Thread.sleep(4000);
        wb.findElement(By.xpath("//div[@id='ctl00_mainContent_ddl_destinationStation1_CTNR']//a[@value='MAA']")).click();
        Thread.sleep(4000);
       
        
        
	}
	

}
