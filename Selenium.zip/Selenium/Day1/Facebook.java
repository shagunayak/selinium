package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook 
{
	public static void main(String args[]) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver wb=new ChromeDriver();
		wb.get("http://www.facebook.com");
		wb.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Anmol");
		wb.findElement(By.xpath("//input[@name='firstname']//following::input[1]")).sendKeys("Srivastava");
		wb.findElement(By.xpath("//input[@name='firstname']//following::input[2]")).sendKeys("8400360614");
		Thread.sleep(2000);
		wb.findElement(By.xpath("//div[@id='u_0_10']//input[@id='u_0_5']")).click();
	}

}
