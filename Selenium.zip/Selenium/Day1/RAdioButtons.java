package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RAdioButtons 
{
	public static void main(String args[]) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		driver.get("http://www.spicejet.com");
		Thread.sleep(4000);
	
		
		
		driver.findElement(By.xpath("//*[@id=\"ctl00_mainContent_rbtnl_Trip_1\"]")).click();
		driver.findElements(By.name("ctl00$mainContent$rbtnl_Trip")).get(2).click();
		System.out.println(driver.findElements(By.name("ctl00$mainContent$rbtnl_Trip")).get(2).getAttribute("value"));
		
		
	    	
	}

}
