package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class ActionAndActions
{
public static void main(String args[]) 
{
	System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("http://demowebshop.tricentis.com/");
    //Action and actions are two different classes 
	//actions are events whereas Action is set of an events as more abstract one
	WebElement we=driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/a"));
	WebElement notebook=driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/ul/li[2]/a"));
	Actions a=new Actions(driver);

	Action set1=a
			.moveToElement(we)
			.click(notebook)
			.build();
	
	
	set1.perform();


}
	
	
	
}
