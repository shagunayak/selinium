package Testing;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment5 
{
	public static double calculateGrandTotal(WebDriver driver) 
	{
		
		double result=0;
		for(int i=2;i<4;i++) 
		{
			double a=0;
			double b=0;
			for(int j=2;j<4;j++) 
			{
				
				if(j==2) 
				{
					
				String s="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+i+"]/td["+j+"]";
				String s2=driver.findElement(By.xpath(s)).getText();
				String s1=s2.substring(1);
				
				a=Double.parseDouble(s1);
				System.out.println(a);
				
				}
				if(j==3) 
				{
					String s3="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+i+"]/td[3]/input";
		
					String s2=driver.findElement(By.xpath(s3)).getAttribute("value");
					b=Double.parseDouble(s2);
					result=result+(a*b);
				}
				}
		}
	    
		return result;
	}
	private static void checkGrandTotal(WebDriver driver,String result) 
	{
		// TODO Auto-generated method stub
		///html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p/text()
	String s=driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p")).getText();


	if(s.contains(result)) 
	{
		System.out.println("GrandTotal is correct");
	}
	else 
	{
		System.out.println("GrandTotal is Incorrect");
	}
	
	}
	private static void checkTotalColumn(WebDriver driver) 
	{
		// TODO Auto-generated method stub
		for(int i=2;i<4;i++) 
		{
			double temp=0;
			double a=0;
			double b=0;
			double c=0;
			for(int j=2;j<5;j++) 
			{
				
				if(j==2) 
				{
					
				String s="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+i+"]/td["+j+"]";
				String s2=driver.findElement(By.xpath(s)).getText();
				String s1=s2.substring(1);
				
				a=Double.parseDouble(s1);
				
				
				}
				if(j==3) 
				{
					String s3="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+i+"]/td[3]/input";
					
					String s2=driver.findElement(By.xpath(s3)).getAttribute("value");
					b=Double.parseDouble(s2);
					temp=(a*b);
				}
				if(j==4) 
				{
					String s3="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+i+"]/td[4]";
		
					String s2=driver.findElement(By.xpath(s3)).getText();
					String s5=s2.substring(1);
					c=Double.parseDouble(s5);
					
					
				}
				if(temp==c&&temp!=0&&c!=0)
				{
				System.out.println("Total for row "+i+" is correct");
				
				}
				
			}
		}
		
	}
	public static void main(String args[]) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://examples.codecharge.com/Store/Default.php");
		WebElement we=driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select"));
		we.click();
		Thread.sleep(2000);
		Select sel=new Select(we);
		sel.selectByVisibleText("Databases");
		driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")).click();
		String product1=driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).getText();
		System.out.println(product1);
		driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();
		driver.findElement(By.xpath("//input[@name='Insert1']")).click();
		driver.findElement(By.xpath("//a[@class='TopMenuLink']")).click();
		WebElement wee=driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select"));
		wee.click();
		Thread.sleep(2000);
		Select sell=new Select(wee);
		sell.selectByVisibleText("Programming");
		driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")).click();
		String product2=driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).getText();
		System.out.println(product2);
		driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")).click();

		driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).clear();
		driver.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")).sendKeys("2");;
		driver.findElement(By.xpath("//input[@name='Insert1']")).click();
		double result=Assignment5.calculateGrandTotal(driver);
		System.out.println(result);
		String s4=Double.toString(result);
		Assignment5.checkGrandTotal(driver,s4);
		Assignment5.checkTotalColumn(driver);
		Assignment5.checkProducts(driver, product1,product2);
	}
	private static void checkProducts(WebDriver driver,String product1, String product2)
	{
	ArrayList<String> a=new ArrayList<>();
	for(int i=2;i<4;i++) 
	{
		for(int j=1;j<2;j++) 
		{
			String s="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+i+"]/td["+j+"]";
		    a.add(driver.findElement(By.xpath(s)).getText());
		
		}
	}

	if(a.get(0).contains(product1)&&a.get(1).contains(product2))
	{
		
		System.out.println("Product are displayed orrectly");
		///html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr[2]/td[1]
	}
		
	}
	
	

}

