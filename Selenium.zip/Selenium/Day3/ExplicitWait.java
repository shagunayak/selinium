package Testing;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitWait
{
	public static void main(String args[]) 
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http:google.com");
		driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input")).sendKeys("stack overfow");
		driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input")).sendKeys(Keys.ENTER);
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		WebDriverWait wait=new WebDriverWait(driver,20);
		WebElement we=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("")));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("")));
		//important note below
		//it will wait for some time only for elements which we get from wait
		//d will work for only single web element 20 is no more applicable and it will switch to implicit wait
		
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("")));
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	

}
