package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class MoveTotetsing
{
	public static void main(String args[]) 
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://facebook.com");
		Actions a=new Actions(driver);
		WebElement firstname=driver.findElement(By.xpath("//*[@id=\"u_0_l\"]"));
		WebElement surname=driver.findElement(By.xpath("//*[@id=\"u_0_n\"]"));
        Action set1=a.moveToElement(firstname).click().sendKeys("java").doubleClick().keyDown(firstname, Keys.CONTROL).sendKeys("c").keyUp(firstname,Keys.CONTROL).build();
		Action set2=a.moveToElement(surname).click().keyDown(surname,Keys.CONTROL).sendKeys("v").sendKeys(surname,Keys.CONTROL).build();
		set1.perform();
		set2.perform();
		driver.close();
		
	}

}
