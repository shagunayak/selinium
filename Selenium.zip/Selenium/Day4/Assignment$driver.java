package Testing;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment$driver 
{
	
	public static void main(String args[]) throws IOException, InterruptedException 
	{
		
		ArrayList<Credential> cds=new ArrayList<>();
		for(int i=1;i<5;i++) 
		{
			
			cds.add(Assignment4.readExcel(i));
			
			
		}
		
		for(int j=0;j<4;j++) 
		{
			System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("http://demowebshop.tricentis.com");
			driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	        driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys((cds.get(j)).getEmail());
	        driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys((cds.get(j)).getPassword());
			driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(Keys.ENTER);
			//Assignment$driver.LogIn(driver, cds, j);
			Thread.sleep(2000);
			System.out.println(driver.getTitle());
			Thread.sleep(2000);
			if(driver.getTitle().equals("Demo Web Shop. Login")&&(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span")).getText().contains("Please enter a valid email address.")))
			{
				
				Assignment4.writeExcel(j+1,"Please enter a valid email address.");
				
				
			}
			else
				if(driver.getTitle().equals("Demo Web Shop. Login")&&(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText().contains("Login was unsuccessful. Please correct the errors and try again."))) 
				{
					Assignment4.writeExcel(j+1,"Login was unsuccessful. Please correct the errors and try again.");
				}
			if(driver.getTitle().equals("Demo Web Shop"))
			{
				String s=driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
				Assignment4.writeExcel(j+1,s);
			}
			
			driver.close();
		}
		for(int k=1;k<5;k++) 
		{
			Assignment4.verifyExcel(k);	
		}
		
		
		
		
	}

}
