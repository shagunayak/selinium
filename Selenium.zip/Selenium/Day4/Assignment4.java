package Testing;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment4 
{
	public static Credential readExcel(int rowIndex) throws IOException 
	{
		
		File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\DemoWebShop.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheet("Sheet1");
		XSSFRow row=sheet.getRow(rowIndex);
		XSSFCell cell1=row.getCell(0);
		DataFormatter df=new DataFormatter();
		String emailId=df.formatCellValue(cell1);
		XSSFCell cell2=row.getCell(1);
		String password =df.formatCellValue(cell2);
		Credential cd=new Credential(emailId,password);
		return cd;
		
		
		
		
		
		
		
		
		
	}
	
	public static void writeExcel(int rowIndex,String s) throws IOException 
	{
		
		File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\DemoWebShop.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheet("Sheet1");
		XSSFRow row=sheet.getRow(rowIndex);
		XSSFCell cell1=row.createCell(3);
		cell1.setCellValue(s);
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		
		
		
	}
	public static void verifyExcel(int rowIndex) throws IOException 
	{
		File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\DemoWebShop.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheet("Sheet1");
		XSSFRow row=sheet.getRow(rowIndex);
		XSSFCell cell2=row.getCell(2);
		XSSFCell cell3=row.getCell(3);
		XSSFCell cell4=row.createCell(4);
		
		String ExpectedValue=cell2.getStringCellValue();
		String ActualValue=cell3.getStringCellValue();
		if(ExpectedValue.contains(ActualValue)) 
		{
		cell4.setCellValue("Pass");
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		}
		else 
		{
			cell4.setCellValue("Fail");
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		}
	}
	
	
	

}
