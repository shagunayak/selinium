package Testing;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultipleWindows 
{
public static void main(String args[]) 
{
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	
	driver.get("https://www.google.com/intl/en-GB/gmail/about/#");
	System.out.println(driver.getTitle());
	
	driver.findElement(By.xpath("/html/body/footer/section/ul[2]/li[1]/a")).click();
	Set<String> ids=driver.getWindowHandles();
	Iterator<String> it=ids.iterator();
	driver.switchTo().window(it.next());
	driver.switchTo().window(it.next());
	//first next will give the first web page since at starting it points before it
	System.out.println(driver.getTitle());


}
}
