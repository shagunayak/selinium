package PracticeTestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebShopBaseClass 
{
	
	public WebDriver getChromeDriver() 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		return driver;
	}
	public void launchURL(WebDriver driver,String url) 
	{
		
		driver.get(url);
		
		
	}
	
	
	public String loginTest(WebDriver driver,String emailid,String password) 
	{
		
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(emailid);
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(password);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();		
	   System.out.println(driver.getTitle());
		if(driver.getTitle().contentEquals("Demo Web Shop. Login")) 
	    {
		String actualresult=driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText();	
	    return actualresult;
	    }
		if(driver.getTitle().contentEquals("Demo Web Shop")) 
		{
			return driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		}
	    return "null";
	}
        
	
}

