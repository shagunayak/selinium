
package PracticeTestNG;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class DemoWebShopDrievr extends DemoWebShopBaseClass  


{
	WebDriver driver;
	
	@BeforeMethod
	public void launch() 
	{
		driver=getChromeDriver();
		launchURL(driver,"http://demowebshop.tricentis.com/login");
	}
	@AfterMethod
	public void close() 
	{
		driver.close();
	}
	

  @Test
  public void loginTest() 
  
 {
	  
	 
	
	  TestData td1=new TestData("anmolsivastava5000@gmail.com","anmol123","Login was unsuccessful. Please correct the errors and try again.\n" + 
		  		"The credentials provided are incorrect"); 
	  String actualResult=loginTest(driver,td1.emailid,td1.password);
	
	   Assert.assertEquals(actualResult, td1.expectedResult);
	   
	  
	  
	  
  }
  @Test
  public void loginTest2() 
  {
	
	  TestData td2=new TestData("anmolsivastava5000.com","anmol123","anmolsivastava5000@gmail.com");
      String ActualResult=loginTest(driver,td2.emailid,td2.password);
      Assert.assertEquals(ActualResult, td2.expectedResult);
  }
  @Test
  public void logintest3() 
  {
	
	  TestData td3=new TestData("anmolsivastava5000","anmol123","Please enter a valid email address.");
      String ActualResult=loginTest(driver,td3.emailid,td3.password);
      Assert.assertEquals(ActualResult, td3.expectedResult);
	  
  }
  @Test
  public void logintest4() 
  {
	
	  TestData td4=new TestData("a1b2c3@gmail.com","anmol123","a1b2c3@gmail.com");
      String ActualResult=loginTest(driver,td4.emailid,td4.password);
      Assert.assertEquals(ActualResult, td4.expectedResult);
	  
  }
}
