package PracticeTestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class FacebookGenric
{
	
	public void launchUrl(WebDriver driver, String url) 
	{
		// TODO Auto-generated method stub
	driver.get(url);	


	}
	
	public WebDriver launchDriver() 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		return driver;
	}

  
  public void credentialsFacebook(WebDriver driver) 
  {
		
		driver.findElement(By.xpath("//*[@id=\"u_0_l\"]")).sendKeys("Anmol");
		driver.findElement(By.xpath("//*[@id=\"u_0_n\"]")).sendKeys("Srivastava");
		driver.findElement(By.xpath("//*[@id=\"u_0_q\"]")).sendKeys("anmolsivastava5000@gmail.com");
	    driver.findElement(By.xpath("//*[@id=\"u_0_x\"]")).sendKeys("anmol123");
	    Select sel=new Select(driver.findElement(By.xpath("//*[@id=\"day\"]")));
	    sel.selectByVisibleText("9");
	    Select sel2=new Select(driver.findElement(By.xpath("//*[@id=\"month\"]")));
	    sel2.selectByVisibleText("Jun");
	    Select sel3=new Select(driver.findElement(By.xpath("//*[@id=\"year\"]")));
	    sel3.selectByVisibleText("1996");
	    driver.findElements(By.xpath("//input[@type='radio']")).get(1).click();
	    
	   
  }

}
