package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Guru99
{
	public static void launchURL(WebDriver driver,String url) 
	{
		
		driver.get(url);
		
		
	}
	
	public static void submitData(WebDriver driver,String Data) 
	{
		
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys(Data);
		driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]")).click();
		
		
	}
	
	public static void acceptAlert(WebDriver driver) 
	{
		
	driver.switchTo().alert().accept();
	
	}
	public static void dismissAlert(WebDriver driver) 
	{
		
	driver.switchTo().alert().dismiss();
	
	}
	
	public static WebDriver getChromeDriver() 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		return driver;
	}
	public static WebDriver getFirefoxDriver() 
	{
		System.setProperty("webdriver.gecko.driver","C:\\Users\\anmol.srivastava\\Desktop\\geckodriver.exe");
		WebDriver wb=new FirefoxDriver();
		return wb;
		
	}
public static String getAlertText(WebDriver driver) 
{
	String s=driver.switchTo().alert().getText();
	return s;
}
public static void resetData(WebDriver driver,String data) 
{
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input")).sendKeys(data);;
	
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[2]")).click();
}
public static void acceptSuccessfullyDelete(WebDriver driver) 
{
	driver.switchTo().alert().accept();
}
}
