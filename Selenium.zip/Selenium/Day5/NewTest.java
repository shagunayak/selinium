package PracticeTestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest 
{
	//Before Method Annotation
	//After Method Annotation
	//Alters Sequence of Execution 
	//Before method is executed before every test method every time 
	//After method is executed after every test method every time
	//reusabilty increases 
	//Before class method executed at the very first and only once in a class
	//After class method executed once after every thing is executed only once generally to do cleanup things 
	//test methods are executed in alphabetical order
	//Flow of execution will not change by the positioning of these methods as mentioned below
	//Giving priority as a parameter in the annotation we can change the flow of executions
	//Using Assert execution stops is assert fails to avoid this we can use softAssert
	//When we have test cases distributed in different testng classes we have to form a testng suite 
	@BeforeClass
	public void beforeClass() 
	{
		System.out.println("before class");
	}
	@AfterClass
	public void afterClass() 
	{
		System.out.println("after class");
	}
	@AfterMethod
	public void afterMethod() 
	{
		System.out.println("After Method");
	}
	@BeforeMethod
	public void beforeMethod() 
	{
		System.out.println("Before Method");
	}
	
  @Test(priority=6)
  public void a() 
  {
	  System.out.println("a");
  }
  @Test(priority=5)
  public void b() 
  {
	  System.out.println("b");
  }
  @Test(priority=4)
  public void c() 
  {
	  System.out.println("c");
	  
  }
}

