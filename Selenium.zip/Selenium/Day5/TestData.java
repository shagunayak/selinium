package PracticeTestNG;

public class TestData 
{
	String emailid;
	String password;
	String expectedResult;
	public TestData(String emailid, String password, String expectedResult) {
		super();
		this.emailid = emailid;
		this.password = password;
		this.expectedResult = expectedResult;
	};

}
