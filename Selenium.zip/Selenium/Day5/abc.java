package PracticeTestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class abc extends FacebookGenric
{
	
  @Test
  public void checkingABC() 
  {
	  
	  WebDriver driver=launchDriver();
	  launchUrl(driver, "http://facebook.com");
	  credentialsFacebook(driver);
	  
  }


}
