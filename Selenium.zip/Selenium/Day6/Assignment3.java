package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment3 
{
	public static void main(String args[]) 
	{
		
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com");
		//driver.manage().tim, arg1)
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("a1b2c3@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("anmol123");
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(Keys.ENTER);
		
		if(driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText().equals("a1b2c3@gmail.com")) 
		{
			System.out.println("Correct email id is displayed");
		}
		else 
		{
			System.out.println("Wrong email id is displayed");
		}
		
		
		
		
		
		
		
		
		
		
		
	}

}
