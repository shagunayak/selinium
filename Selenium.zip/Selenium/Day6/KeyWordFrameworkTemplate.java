package Testing;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class KeyWordFrameworkTemplate 
{

	WebDriver driver;
	
	public void click(String xpath) 
	{
		driver.findElement(By.xpath(xpath)).click();	
	}
public  void launchBrowser(String url) 
	{
		driver.get(url);
	}
public  void enterText(String xpath,String Data) 
{
	driver.findElement(By.xpath(xpath)).sendKeys(Data);
}
public void verify(String expectedResult,String xpath) throws IOException 
{
	String actualResult=driver.findElement(By.xpath(xpath)).getText();
	if(actualResult.contains(expectedResult)) 
	{
	keywordWriteExcel.writeExcel("Pass");	
	}
	else 
	{
		keywordWriteExcel.writeExcel("fail");
	}
		
}
	
	
	
	
	

}
