package Testing;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class keyWordDriver extends KeyWordFrameworkTemplate
{
	public static void main(String args[]) throws IOException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		
		KeyWordFrameworkTemplate template=new KeyWordFrameworkTemplate();
		template.driver=new ChromeDriver();
		ArrayList<keyWordObject> al=new ArrayList<>();
		for(int i=1;i<7;i++) 
		{
			
			
			al.add(keywordDrivenReadExcel.readExcel(i));
			
		}
		
	
	
		for(int j=0;j<6;j++)
		{
			
			keyWordObject temp=al.get(j);
			switch(temp.keyword) 
			{
			case "launchBrowser":
			{
				
				template.launchBrowser(temp.testData);
break;
			
			}
			case "click":
			{
			  
				template.click(temp.xpath);
				break;				
				
			}
			case "enterText":
			{
				template.enterText(temp.xpath,temp.testData);
				break;
			}
			
			
			
			case "verify":
			{
				template.verify(temp.testData,temp.xpath);
				break;
			}
			
			default:
				System.out.println("no matching parameter found");
				break;	
			}
			}
			
			
	
			
			
		}
		
		
		
		
		
		
	}


