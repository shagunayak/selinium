package Testing;

public class keyWordObject 

{
	String userAction;
	String keyword;
	String xpath;
	String testData;
	public keyWordObject(String userAction, String keyword, String xpath, String testData) {
	
		this.userAction = userAction;
		this.keyword = keyword;
		this.xpath = xpath;
		this.testData = testData;
	}
	
	
	

}
