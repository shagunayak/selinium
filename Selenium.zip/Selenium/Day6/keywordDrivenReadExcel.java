package Testing;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class keywordDrivenReadExcel
{
	public static keyWordObject readExcel(int rowIndex) {

	try {
		File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\KeyWord Driven Framework.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook xb=new XSSFWorkbook(fis);
	    XSSFSheet sheet=xb.getSheet("Sheet1");
	    XSSFRow row=sheet.getRow(rowIndex);
	    XSSFCell userAction=row.getCell(0);
	    XSSFCell keyWord=row.getCell(1);
	    XSSFCell xpath=row.getCell(2);
	    XSSFCell testdata=row.getCell(3);
	    DataFormatter df=new DataFormatter();
	    String p=df.formatCellValue(userAction);
	    String q=df.formatCellValue(keyWord);
	    String r=df.formatCellValue(xpath);
	    String s=df.formatCellValue(testdata);
	    
	  // String productIdValue=productId.getStringCellValue();
	  // String productNameValue=productName.getStringCellValue();
	  // String ratePerUnitValue=ratePerUnit.getStringCellValue();
	  //String UnitsPurchasedValue=UnitsPurchased.getStringCellValue();
	    keyWordObject p1=new keyWordObject(p,q,r,s);
	    return p1;
	
     	}
 	catch (Exception e) 
	{
		
		e.printStackTrace();
	
	}
	return null;
	
	}
	
	
	
	
	

}
