package Testing;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class keywordWriteExcel

{

	public static void writeExcel(String s) throws IOException 
	{
		
		File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\KeyWord Driven Framework.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheet("Sheet1");
		XSSFRow row=sheet.getRow(6);
		XSSFCell cell1=row.createCell(4);
		cell1.setCellValue(s);
		FileOutputStream fos=new FileOutputStream(f);
		wb.write(fos);
		
		
		
	}
	
}
