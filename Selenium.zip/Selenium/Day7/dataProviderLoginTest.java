package PracticeTestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataProviderLoginTest {
 
	
	@Test(dataProvider="datasource")
  public void loginTest(String emailid,String password) 
  {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com/login");
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(emailid);
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(password);
	    driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
  }
	@BeforeClass
	@DataProvider(name="datasource")
	public String[][] datadata()
	{
		return readExcel.readExcel();
	}
}
