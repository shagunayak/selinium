package PracticeTestNG;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataProviderTest 
{
	
	@Test(dataProvider="datasource")
	public void test1(String firstname,String lastname,String empID) 
	{
		
		System.out.println("The full name is "+firstname+" "+lastname+"and the employee id is "+empID);
		
	}
	@DataProvider(name="datasource")
	public String[][] datadata()
	{
		
		String[][] data= 
			{
					
			
					{"anmol","srivastava","323586"},
					{"shagun","nayak","323576"},
					{"anant","raman","323577"}
				
		   };
		return data;
	}
	

}
//the number of test data in dataprovider no of tests will be run

