package PracticeTestNG;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Testing.keyWordObject;

public class readExcel 
{

	public static String[][] readExcel() {

		try {
			String data[][]=new String[4][2];
			File f=new File("C:\\Users\\anmol.srivastava\\Desktop\\DataProvider.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook xb=new XSSFWorkbook(fis);
		    XSSFSheet sheet=xb.getSheet("Sheet1");
		   
		    //XSSFCell xpath=row.getCell(2);
		    //XSSFCell testdata=row.getCell(3);
		    
		    //String r=df.formatCellValue(xpath);
		    //String s=df.formatCellValue(testdata);
		    for(int rowIndex=1;rowIndex<5;rowIndex++)
		    {
		    	     XSSFRow row=sheet.getRow(rowIndex);
				     XSSFCell emailid=row.getCell(0);
			         XSSFCell password=row.getCell(1);
				     DataFormatter df=new DataFormatter();
				     String p=df.formatCellValue(emailid);
				     String q=df.formatCellValue(password);
			data[rowIndex-1][0]=p;
			data[rowIndex-1][1]=q;
		    }
		    return data;
		  // String productIdValue=productId.getStringCellValue();
		  // String productNameValue=productName.getStringCellValue();
		  // String ratePerUnitValue=ratePerUnit.getStringCellValue();
		  //String UnitsPurchasedValue=UnitsPurchased.getStringCellValue();
		   // keyWordObject p1=new keyWordObject(p,q,r,s);
		  //  return p1;
		
	     	}
	 	catch (Exception e) 
		{
			
			e.printStackTrace();
		
		}
		return null;
		
		}
		
		
		

}
