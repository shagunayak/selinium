package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class AssertionsTest
{

	

	public static void main(String args[]) 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://spicejet.com");
		driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).click();
		System.out.println(driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).isSelected());
		Assert.assertTrue(driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).isSelected());
		//Assert.assertFalse(driver.findElement(By.id("ctl00_mainContent_chk_friendsandfamily")).isSelected());
		//assertions will stop further execution
		System.out.println(driver.findElements(By.xpath("//input[@type='checkbox']")).size());
	    Assert.assertEquals(driver.findElements(By.xpath("//input[@type='checkbox']")).size(),5);
	    System.out.println("Aaaassssseeeerrrrrrttttttt");
	
	
	
	
	
}
	
	
	
	
}
