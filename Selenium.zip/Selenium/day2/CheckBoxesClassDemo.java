package Testing;

public class CheckBoxesClassDemo 
{
	
	public static void main(String args[]) 
	{
		
		
		
		
		
	}

}
