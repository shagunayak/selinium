package Testing;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EnablingUIElement
{
	public static void main(String args[]) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver wb=new ChromeDriver();
		wb.get("http://www.spicejet.com");
		Thread.sleep(3000);
		System.out.println(wb.findElement(By.xpath("//*[@id=\"ctl00_mainContent_view_date2\"]")).isEnabled());
		List<WebElement> rb=new ArrayList<>();
		rb=wb.findElements(By.name("ctl00$mainContent$rbtnl_Trip"));
		
		for(WebElement w: rb) 
		{
			
			//System.out.println(w.getAttribute("value"));
			if(w.getAttribute("value").equals("RoundTrip")) 
			{
				
			w.click();
			break;
			
			
			}
		
		
		}
		System.out.println(wb.findElement(By.xpath("//*[@id='ctl00_mainContent_view_date2']")).isEnabled());
		wb.findElement(By.xpath("//*[@id=\"flightSearchContainer\"]/div[4]/button")).click();
		Thread.sleep(2000);
		wb.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div[1]/table/tbody/tr[5]/td[3]/a")).click();
		Thread.sleep(2000);
		wb.findElement(By.xpath("//*[@id=\"Div1\"]/button")).click();
		Thread.sleep(2000);
		wb.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div[1]/table/tbody/tr[2]/td[3]")).click();
		//wb.findElement(By.id("ctl00_mainContent_view_date2")).click();
	   //wb.findElement(By.id("MultiCityModelAlert")).click();
		
		
	
	
	
	
	
	
	
	}

}
