package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HTMLTables 
{
	public static void main(String args[]) 
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.w3schools.com/html/html_tables.asp");
		int i;
		int j;
		
		// //*[@id="customers"]/tbody/tr[1]/th[1]: R1C1
		// //*[@id="customers"]/tbody/tr[2]/td[3]: R2C2
		// //*[@id="customers"]/tbody/tr[3]/td[2]: R3C2

		for(i=2;i<8;i++) 
		
		{
			
			for(j=1;j<4;j++) 
			{
				
		      String s= "//*[@id=\"customers\"]/tbody/tr["+i+"]/td["+j+"]";
			    System.out.print(driver.findElement(By.xpath(s)).getText()+" ");
			    
			
			
			}
			System.out.println(" ");
		}
		
		
		
	}

}
