package Testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaAlert
{
	//If we spy and inpect and if we get some code then this web element can be handled
	//web related,pop up and java pop up are two different things
	//Selenium cannot handle non HTML web element specially java alert
public static void main(String args[]) throws InterruptedException 
{
	

	System.setProperty("webdriver.chrome.driver","C:\\Users\\anmol.srivastava\\Desktop\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.tizag.com/javascriptT/javascriptalert.php");
	Thread.sleep(4000);
	driver.findElement(By.xpath("//input[@value='Confirmation Alert']")).click();
	System.out.println(driver.switchTo().alert().getText());
	driver.switchTo().alert().accept();
	//switching from web element to alert java element
	// for canceling the alerts driver.switchTo().alert().dismiss();
	//if we want to enter something into pop up box
	//driver.switchTo().alert().sendKeys("");	
}	
	

}
